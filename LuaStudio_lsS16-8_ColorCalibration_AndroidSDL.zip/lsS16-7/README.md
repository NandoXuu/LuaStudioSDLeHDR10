

## Skybox customizavel e ciclo dia/noite

O ambiente `Env3D` aceita uma imagem de céu panoramica (`SkyTexture`) ou um gradiente (`SkyTop`/`SkyBottom`). A textura e desenhada como pano de fundo e pode ser escalada e deslocada. O sol usa por padrao `assets/engine/sun.png`, que pode ser substituido via `SunTexture`.

```lua
Env3D.set({
  SkyTexture = "assets/skybox_california.png", -- imagem panoramica/de fundo
  SkyScale = 1.0, SkyWidth = 1.0, SkyHeight = 1.0,
  SkyOffsetX = 0.0, SkyOffsetY = 0.0,
  SunTexture = "assets/engine/sun.png", SunSize = 112,
  SunEnabled = true, SunOrbit = true,
  DayNight = true, DayLength = 300, WorldTime = 0.20
})
```

`WorldTime` varia de 0 a 1 para um ciclo completo. `DayLength` e a duracao em segundos do ciclo quando `DayNight = true`. `SkyWidth`, `SkyHeight` e `SkyScale` controlam a escala do pano de fundo; `SkyOffsetX/Y` deslocam a imagem. Coloque texturas dentro da pasta do projeto e use caminhos relativos. A skybox de imagem nesta versao e um pano de fundo texturizado 2D/equiretangular, nao uma skybox cubica de seis faces com amostragem por direcao de camera. O sol e um sprite texturizado desenhado sobre o ceu; sua orbita acompanha o relogio do mundo.
